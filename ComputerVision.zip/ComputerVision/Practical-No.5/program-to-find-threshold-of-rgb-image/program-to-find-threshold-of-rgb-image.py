# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import numpy as np  # NumPy for numerical operations
import matplotlib.pyplot as plt  # Matplotlib for plotting

# Function to apply thresholding on an RGB image
def apply_rgb_threshold(image):
    """
    This function applies binary thresholding to each channel of an RGB image.
    Args:
    - image: Input image in RGB format
    Returns:
    None
    """
    try:
        # Split the image into its respective channels
        b_channel, g_channel, r_channel = cv2.split(image)

        # Apply binary thresholding to each channel
        _, b_thresholded = cv2.threshold(b_channel, 127, 255, cv2.THRESH_BINARY)
        _, g_thresholded = cv2.threshold(g_channel, 127, 255, cv2.THRESH_BINARY)
        _, r_thresholded = cv2.threshold(r_channel, 127, 255, cv2.THRESH_BINARY)

        # Merge the thresholded channels back into a single image
        thresholded_image = cv2.merge((b_thresholded, g_thresholded, r_thresholded))

        # Display original and thresholded images
        plt.figure(figsize=(10, 5))

        plt.subplot(1, 2, 1)
        plt.title('Original RGB Image')
        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.title('Thresholded Image')
        plt.imshow(cv2.cvtColor(thresholded_image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.show()

    except Exception as e:
        print(f"An error occurred during thresholding: {e}")

# Main code to load the image and apply thresholding
if __name__ == "__main__":
    try:
        # Load the image (make sure you have an image named 'sample_image.jpg' in the same folder as this script)
        image = cv2.imread('sample_image.jpg')

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError("Error: Image not found. Make sure the image file exists in the same directory.")
        
        # Apply thresholding on the RGB image
        apply_rgb_threshold(image)

    except FileNotFoundError as fnf_error:
        print(fnf_error)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
