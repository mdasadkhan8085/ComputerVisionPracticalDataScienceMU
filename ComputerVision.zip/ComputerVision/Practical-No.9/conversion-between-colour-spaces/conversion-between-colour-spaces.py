# Import commands for terminal:
# pip install opencv-python
# pip install matplotlib

# Import the necessary libraries
import cv2  # OpenCV for image processing
import matplotlib.pyplot as plt  # Matplotlib for plotting

def convert_color_spaces(image_path):
    """
    Load an image and convert it between different color spaces.
    
    Args:
    - image_path: Path to the image file
    """
    try:
        # Load the color image
        image = cv2.imread(image_path)

        # Check if the image was loaded successfully
        if image is None:
            raise FileNotFoundError(f"Error: Image not found at {image_path}. Please check the path.")

        # Convert the image from BGR to RGB format
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Convert the RGB image to Grayscale
        image_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Convert the RGB image to HSV
        image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

        # Convert the RGB image to LAB
        image_lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)

        # Create a figure to display the images
        plt.figure(figsize=(15, 10))

        # Display the original image (RGB format)
        plt.subplot(2, 2, 1)
        plt.imshow(image_rgb)
        plt.axis('off')
        plt.title('Original Image (RGB)')

        # Display the Grayscale image
        plt.subplot(2, 2, 2)
        plt.imshow(image_gray, cmap='gray')
        plt.axis('off')
        plt.title('Grayscale Image')

        # Display the HSV image
        plt.subplot(2, 2, 3)
        plt.imshow(image_hsv)
        plt.axis('off')
        plt.title('HSV Image')

        # Display the LAB image
        plt.subplot(2, 2, 4)
        plt.imshow(cv2.cvtColor(image_lab, cv2.COLOR_LAB2RGB))
        plt.axis('off')
        plt.title('LAB Image')

        # Show the images
        plt.tight_layout()
        plt.show()

    except FileNotFoundError as fnf_error:
        print(fnf_error)  # Print the error message for file not found
    except Exception as e:
        print(f"An unexpected error occurred: {e}")  # Catch any other exceptions

# Main code to execute the conversion function
if __name__ == "__main__":
    try:
        # Specify the path to your image file
        image_path = 'sample_image.jpg'  # Change this to the path of your image
        convert_color_spaces(image_path)

    except Exception as e:
        print(f"An unexpected error occurred: {e}")
